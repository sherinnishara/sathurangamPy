import sathurangamPy as sp
import cv2
import numpy as np
# path = 'logo.jpg'
# file = 'sathurangamPy/haarcascade_frontalface_default.xml'
# datafolder = 'sathurangamPy/datasets'
# sub_data = 'go'

# disp = sp.display_image(path)
# print(disp)

# canny = sp.canny_edge(path, 7, 100, 200)
# dilate = sp.dilate_image(path, 5, 100, 200, 1)

# save = sp.save_face(0, datafolder, sub_data, file, 2)

# print(save)